greeting = "Hola mundo"
print(greeting)
greeting = "Hola planeta"
print(greeting)
