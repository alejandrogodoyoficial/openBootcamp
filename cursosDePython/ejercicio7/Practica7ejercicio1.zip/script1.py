from calculator import *
print(sum(2,2))
print(sub(5,3))
print(multiply(3,2))
print(divide(4,2))
