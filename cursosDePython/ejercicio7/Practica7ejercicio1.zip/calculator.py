def sum(a, b):
  return a + b

def  sub(a, b):
  return a - b

def multiply(a,b):
  return a * b

def divide(a, b):
  return a / b
