myList = range(100)
print(list(filter(lambda x : x % 2 != 0,myList)))