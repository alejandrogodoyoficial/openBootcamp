Ingrese python script.py en la consola de comando y luego los valores que quiere que se muestren por pantalla.
Ejemplo python script.py "Hola mundo", esto imrpimira -> ["Hola mundo"]
