package practica4.src.com.practica4;

public class Main {
    public static void main(String[] args) {

        SmartPhone iphone13 = new SmartPhone();
        SmartWatch HaylouLS80 = new SmartWatch();
        System.out.println(iphone13);
        System.out.println(HaylouLS80);
    }
}