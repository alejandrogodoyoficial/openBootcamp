package practice3.src.com.ejercice3;

public class Main {
    public static void main(String[] args) {
        String[] palabras = { "Hola ", "a ", "todos ", "como ", "estan ", "?" };
        for (String palabra : palabras) {
            System.out.print(palabra);
        }

    }
}