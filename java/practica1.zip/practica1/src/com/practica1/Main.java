package com.practica1;

public class Main {
    public static void main(String[] args) {
        // intergers
        byte num1 = 122;
        short num2 = 255;
        int num3 = 23333;
        long num4 = 123123123;

        // Float and double
        float num5 = 5.4f;
        double num6 = 94.3334653d;

        // Boolean
        boolean t = true;
        boolean f = false;

        String something = "Hello";

        System.out.println("byte: " + num1);
        System.out.println("short: " + num2);
        System.out.println("int: " + num3);
        System.out.println("long: " + num4);
        System.out.println("float: " + num5);
        System.out.println("double: " + num6);
        System.out.println("boolean: " + t + " and " + f);
        System.out.println(something);

    }

}